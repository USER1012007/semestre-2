interface edificio {
  double getSuperficieEdificio();
}
